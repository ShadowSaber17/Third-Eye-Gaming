import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Menu, Minus, Plus, ShoppingBag, X } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Product, formatINR } from "@/data/products";
import { useCart } from "@/contexts/CartContext";

export function BrandMark({ invert = false }: { invert?: boolean }) {
  return (
    <Link href="/" className={`brand-mark ${invert ? "brand-mark--invert" : ""}`} aria-label="Third Eye Gaming home">
      <span className="brand-mark__eye" aria-hidden="true">
        <span />
        <span />
        <span />
      </span>
      <span className="brand-mark__text">
        <strong>THIRD EYE</strong>
        <small>GAMING / V1</small>
      </span>
    </Link>
  );
}

const navItems = [
  { href: "/shop", label: "Shop" },
  { href: "/category/keycaps", label: "Keycaps" },
  { href: "/category/cables", label: "Cables" },
  { href: "/category/mouse-accessories", label: "Mouse" },
  { href: "/about", label: "About" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { totalItems } = useCart();

  return (
    <header className="site-header">
      <div className="site-header__inner">
        <BrandMark />
        <nav className="desktop-nav" aria-label="Primary navigation">
          {navItems.map(item => (
            <Link key={item.href} href={item.href} className={location === item.href ? "is-active" : ""}>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="header-actions">
          <Link href="/cart" className="cart-link" aria-label={`Cart with ${totalItems} items`}>
            <ShoppingBag size={16} strokeWidth={1.7} />
            <span>Bag</span>
            <span className="cart-count">{String(totalItems).padStart(2, "0")}</span>
          </Link>
          <button className="mobile-menu-button" onClick={() => setOpen(value => !value)} aria-label="Toggle menu">
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav
            className="mobile-nav"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            aria-label="Mobile navigation"
          >
            {navItems.map((item, index) => (
              <motion.div key={item.href} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.035 }}>
                <Link href={item.href} onClick={() => setOpen(false)}>{item.label}</Link>
              </motion.div>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="site-footer__top">
        <div>
          <BrandMark invert />
          <p className="footer-note">Placeholder storefront for a more intentional desk setup.</p>
        </div>
        <div className="footer-links">
          <div>
            <span className="micro-label">Explore</span>
            <Link href="/shop">All products</Link>
            <Link href="/category/keycaps">Keycaps</Link>
            <Link href="/category/cables">Cables</Link>
            <Link href="/category/mouse-accessories">Mouse accessories</Link>
          </div>
          <div>
            <span className="micro-label">Project status</span>
            <span>V1 demo catalogue</span>
            <span>INR pricing</span>
            <span>No live payment processing</span>
          </div>
        </div>
      </div>
      <div className="site-footer__bottom">
        <span>© 2026 Third Eye Gaming</span>
        <span>Built for the parts you touch.</span>
      </div>
    </footer>
  );
}

export function SectionLabel({ eyebrow, title, action }: { eyebrow: string; title: string; action?: React.ReactNode }) {
  return (
    <div className="section-heading">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  return (
    <motion.article
      className="product-card"
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.45, delay: index * 0.05 }}
      whileHover={{ y: -5 }}
    >
      <Link href={`/product/${product.slug}`} className="product-card__media">
        <span className="product-card__index">{product.index}</span>
        <motion.img src={product.image} alt="" whileHover={{ scale: 1.045 }} transition={{ duration: 0.5 }} />
        <span className="product-card__arrow"><ArrowUpRight size={17} /></span>
      </Link>
      <div className="product-card__body">
        <div>
          <span className="product-card__collection">{product.collection}</span>
          <Link href={`/product/${product.slug}`} className="product-card__name">{product.name}</Link>
          <p>{product.descriptor}</p>
        </div>
        <span className="product-card__price">{formatINR(product.price)}</span>
      </div>
    </motion.article>
  );
}

export function QuantityControl({ value, onChange }: { value: number; onChange: (value: number) => void }) {
  return (
    <div className="quantity-control" aria-label="Quantity">
      <button onClick={() => onChange(value - 1)} aria-label="Decrease quantity"><Minus size={13} /></button>
      <span>{String(value).padStart(2, "0")}</span>
      <button onClick={() => onChange(value + 1)} aria-label="Increase quantity"><Plus size={13} /></button>
    </div>
  );
}

export function PrimaryButton({ children, href, type = "button", onClick }: { children: React.ReactNode; href?: string; type?: "button" | "submit"; onClick?: () => void }) {
  if (href) {
    return <Button asChild className="button-primary"><Link href={href}>{children}<ArrowUpRight size={15} /></Link></Button>;
  }
  return <Button type={type} onClick={onClick} className="button-primary">{children}<ArrowUpRight size={15} /></Button>;
}

export function MetaStrip({ items }: { items: string[] }) {
  return (
    <div className="meta-strip">
      {items.map(item => <span key={item}>{item}</span>)}
    </div>
  );
}
