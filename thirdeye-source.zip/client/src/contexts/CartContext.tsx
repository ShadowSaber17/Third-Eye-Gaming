import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { Product, products } from "@/data/products";

export interface CartLine {
  productId: string;
  quantity: number;
}

interface CartContextValue {
  lines: CartLine[];
  items: Array<{ product: Product; quantity: number; lineTotal: number }>;
  totalItems: number;
  subtotal: number;
  addToCart: (productId: string, quantity?: number) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "third-eye-gaming-cart";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? (JSON.parse(stored) as CartLine[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
  }, [lines]);

  const items = useMemo(
    () =>
      lines
        .map(line => {
          const product = products.find(candidate => candidate.id === line.productId);
          return product ? { product, quantity: line.quantity, lineTotal: product.price * line.quantity } : null;
        })
        .filter((item): item is { product: Product; quantity: number; lineTotal: number } => Boolean(item)),
    [lines],
  );

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);

  const addToCart = (productId: string, quantity = 1) => {
    setLines(current => {
      const existing = current.find(line => line.productId === productId);
      if (existing) {
        return current.map(line =>
          line.productId === productId ? { ...line, quantity: line.quantity + quantity } : line,
        );
      }
      return [...current, { productId, quantity }];
    });
  };

  const updateQuantity = (productId: string, quantity: number) => {
    setLines(current =>
      quantity <= 0
        ? current.filter(line => line.productId !== productId)
        : current.map(line => (line.productId === productId ? { ...line, quantity } : line)),
    );
  };

  const removeFromCart = (productId: string) => updateQuantity(productId, 0);
  const clearCart = () => setLines([]);

  return (
    <CartContext.Provider
      value={{ lines, items, totalItems, subtotal, addToCart, updateQuantity, removeFromCart, clearCart }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used within CartProvider");
  return context;
}
