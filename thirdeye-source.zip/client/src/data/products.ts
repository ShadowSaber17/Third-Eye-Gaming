export type CategoryKey = "keycaps" | "cables" | "mouse-accessories" | "keychains";

export interface ProductOption {
  label: string;
  values: string[];
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  collection: string;
  category: CategoryKey;
  categoryLabel: string;
  price: number;
  image: string;
  index: string;
  descriptor: string;
  description: string;
  detailLine: string;
  options?: ProductOption[];
}

export const imageAssets = {
  hero: "/manus-storage/async-images/37IVLRJAFl22RPq3SgESHW/image-1.webp",
  keycaps: "/manus-storage/async-images/37IVLRJAFl22RPq3SgESHW/image-2.webp",
  cable: "/manus-storage/async-images/37IVLRJAFl22RPq3SgESHW/image-3.webp",
  mouse: "/manus-storage/async-images/37IVLRJAFl22RPq3SgESHW/image-4.webp",
};

export const products: Product[] = [
  {
    id: "01",
    slug: "signal-01-keycap-set",
    name: "Signal 01 keycap set",
    collection: "Signal series",
    category: "keycaps",
    categoryLabel: "Keycap sets",
    price: 2499,
    image: imageAssets.keycaps,
    index: "01 / 06",
    descriptor: "A clean starting point for a louder board.",
    description: "A placeholder keycap set for exploring the Third Eye Gaming catalogue experience. Product details will be replaced with final specifications before launch.",
    detailLine: "Placeholder catalogue item · INR pricing",
    options: [{ label: "Demo finish", values: ["Graphite", "Signal lime", "Warm white"] }],
  },
  {
    id: "02",
    slug: "afterimage-artisan-keycap",
    name: "Afterimage artisan",
    collection: "Small batch studies",
    category: "keycaps",
    categoryLabel: "Artisan keycaps",
    price: 1299,
    image: imageAssets.keycaps,
    index: "02 / 06",
    descriptor: "One small detail that changes the whole board.",
    description: "A placeholder artisan keycap designed to demonstrate close-up product storytelling and cross-selling in the V1 storefront.",
    detailLine: "Placeholder catalogue item · INR pricing",
    options: [{ label: "Demo finish", values: ["Graphite", "Signal lime"] }],
  },
  {
    id: "03",
    slug: "coil-02-keyboard-cable",
    name: "Coil 02 keyboard cable",
    collection: "Desk connection",
    category: "cables",
    categoryLabel: "Coiled cables",
    price: 1899,
    image: imageAssets.cable,
    index: "03 / 06",
    descriptor: "A deliberate line between board and desk.",
    description: "A placeholder coiled cable for the desk-setup collection. Final connector, length and finish information will be added when the live catalogue is ready.",
    detailLine: "Placeholder catalogue item · INR pricing",
    options: [{ label: "Demo finish", values: ["Graphite", "Warm white", "Signal lime"] }],
  },
  {
    id: "04",
    slug: "eye-contact-keycap-keychain",
    name: "Eye Contact keychain",
    collection: "Carry the signal",
    category: "keychains",
    categoryLabel: "Keycap keychains",
    price: 699,
    image: imageAssets.keycaps,
    index: "04 / 06",
    descriptor: "A tiny piece of the setup, off the desk.",
    description: "A placeholder keycap keychain that gives the catalogue a small, collectible entry point.",
    detailLine: "Placeholder catalogue item · INR pricing",
    options: [{ label: "Demo finish", values: ["Graphite", "Signal lime"] }],
  },
  {
    id: "05",
    slug: "glide-01-mouse-skates",
    name: "Glide 01 mouse skates",
    collection: "Control surface",
    category: "mouse-accessories",
    categoryLabel: "Mouse accessories",
    price: 799,
    image: imageAssets.mouse,
    index: "05 / 06",
    descriptor: "Less drag. More intention.",
    description: "A placeholder mouse-skate product for demonstrating the pro-gaming side of the collection without making unsupported technical claims.",
    detailLine: "Placeholder catalogue item · INR pricing",
    options: [{ label: "Demo profile", values: ["Standard", "Control"] }],
  },
  {
    id: "06",
    slug: "grip-01-mouse-grips",
    name: "Grip 01 mouse grips",
    collection: "Control surface",
    category: "mouse-accessories",
    categoryLabel: "Mouse accessories",
    price: 999,
    image: imageAssets.mouse,
    index: "06 / 06",
    descriptor: "Texture where your hand expects it.",
    description: "A placeholder mouse-grip product for the V1 catalogue. Materials, fit and compatibility details will be added before real commerce is enabled.",
    detailLine: "Placeholder catalogue item · INR pricing",
    options: [{ label: "Demo profile", values: ["Graphite", "Signal lime"] }],
  },
];

export function getProduct(slug?: string) {
  return products.find(product => product.slug === slug);
}

export function formatINR(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
}

export function getRelatedProducts(product: Product) {
  const rules: Record<CategoryKey, CategoryKey[]> = {
    keycaps: ["keycaps", "cables", "keychains"],
    cables: ["keycaps", "cables", "keychains"],
    keychains: ["keycaps", "cables"],
    "mouse-accessories": ["mouse-accessories"],
  };

  return products
    .filter(candidate => candidate.id !== product.id && rules[product.category].includes(candidate.category))
    .slice(0, 3);
}

export const categoryMeta: Record<string, { label: string; eyebrow: string; description: string; image: string }> = {
  keycaps: {
    label: "Keycaps",
    eyebrow: "Shape / texture / signal",
    description: "Start with the surface you touch most. Build from a clean base or add one small point of view.",
    image: imageAssets.keycaps,
  },
  cables: {
    label: "Cables",
    eyebrow: "Connection, made visible",
    description: "A desk line should feel intentional. Browse placeholder cable studies built for the V1 shopping flow.",
    image: imageAssets.cable,
  },
  "mouse-accessories": {
    label: "Mouse accessories",
    eyebrow: "Control surface",
    description: "Small changes at the hand. Explore the pro-gaming side of Third Eye Gaming.",
    image: imageAssets.mouse,
  },
};
