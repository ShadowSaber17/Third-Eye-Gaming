import { ArrowRight, Eye, Hand, Layers3 } from "lucide-react";
import { Link } from "wouter";
import { SiteFooter, SiteHeader } from "@/components/storefront";

const principles = [
  { icon: Eye, number: "01", title: "Notice the detail", text: "The pieces we reach for every day deserve more attention than an afterthought." },
  { icon: Hand, number: "02", title: "Make it tactile", text: "Texture, weight, finish and the feel of the hand belong in the buying decision." },
  { icon: Layers3, number: "03", title: "Build in layers", text: "A setup rarely arrives all at once. The right next piece is part of the fun." },
];

export default function About() {
  return <div className="site-shell"><SiteHeader /><main className="container page-main about-page"><section className="about-hero"><div><span className="eyebrow">Third Eye Gaming / point of view</span><h1>For people who<br /><em>notice the parts.</em></h1></div><p>Third Eye Gaming is a placeholder V1 storefront for keycaps, cables and small accessories around gaming and mechanical-keyboard setups.</p></section><section className="about-statement"><span className="about-statement__index">TE / 03</span><h2>Not a wall of gear.<br /><span>A considered edit.</span></h2><p>The catalogue is built around the moments that happen between the big upgrades: changing the keycaps, tuning the desk line, finding a better point of contact. Start with one thing that feels right. Let the rest follow.</p></section><section className="principles"><span className="eyebrow">The working brief</span><div className="principles-grid">{principles.map(({ icon: Icon, number, title, text }) => <div className="principle" key={number}><span className="principle__number">{number}</span><Icon size={20} strokeWidth={1.4} /><h3>{title}</h3><p>{text}</p></div>)}</div></section><section className="about-cta"><span className="eyebrow">Start with the current edit</span><h2>One small<br /><em>signal.</em></h2><Link href="/shop" className="button-primary button-primary--inline">Browse the pieces <ArrowRight size={15} /></Link></section></main><SiteFooter /></div>;
}
