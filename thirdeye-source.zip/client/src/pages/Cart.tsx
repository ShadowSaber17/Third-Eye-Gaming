import { ArrowRight, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { formatINR } from "@/data/products";
import { useCart } from "@/contexts/CartContext";
import { PrimaryButton, QuantityControl, SiteFooter, SiteHeader } from "@/components/storefront";

export default function CartPage() {
  const { items, subtotal, updateQuantity, removeFromCart } = useCart();
  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="container page-main cart-page">
        <div className="cart-heading"><div><span className="eyebrow">Your selection</span><h1>The bag.</h1></div><span className="cart-heading__count">{String(items.length).padStart(2, "0")} lines</span></div>
        {items.length === 0 ? (
          <div className="empty-state"><span className="empty-state__mark">∅</span><h2>Nothing selected yet.</h2><p>Start with one deliberate piece. The rest can follow.</p><PrimaryButton href="/shop">Browse the edit</PrimaryButton></div>
        ) : (
          <div className="cart-layout">
            <div className="cart-lines">
              {items.map(({ product, quantity, lineTotal }) => <div className="cart-line" key={product.id}><Link href={`/product/${product.slug}`} className="cart-line__image"><img src={product.image} alt="" /></Link><div className="cart-line__info"><span className="micro-label">{product.categoryLabel}</span><Link href={`/product/${product.slug}`} className="cart-line__name">{product.name}</Link><span className="cart-line__note">{product.detailLine}</span></div><QuantityControl value={quantity} onChange={value => updateQuantity(product.id, value)} /><span className="cart-line__price">{formatINR(lineTotal)}</span><button className="icon-button" onClick={() => removeFromCart(product.id)} aria-label={`Remove ${product.name}`}><Trash2 size={15} /></button></div>)}
              <Link href="/shop" className="continue-link"><ArrowRight size={15} /> Keep browsing</Link>
            </div>
            <aside className="cart-summary"><span className="eyebrow">Summary / demo</span><h2>Ready when<br /><em>you are.</em></h2><div className="summary-row"><span>Subtotal</span><strong>{formatINR(subtotal)}</strong></div><div className="summary-row summary-row--muted"><span>Shipping</span><span>Added later</span></div><div className="summary-total"><span>Estimated total</span><strong>{formatINR(subtotal)}</strong></div><PrimaryButton href="/checkout">Continue to checkout</PrimaryButton><p className="summary-note">This is a simulated checkout. No payment or real order will be processed.</p></aside>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
