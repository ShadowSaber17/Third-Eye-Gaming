import { FormEvent, useState } from "react";
import { ArrowLeft, ArrowRight, CheckCircle2, LockKeyhole } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatINR } from "@/data/products";
import { useCart } from "@/contexts/CartContext";
import { SiteFooter, SiteHeader } from "@/components/storefront";

export default function CheckoutPage() {
  const { items, subtotal, clearCart } = useCart();
  const [, navigate] = useLocation();
  const [complete, setComplete] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "", city: "", postal: "" });

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) => setForm(current => ({ ...current, [key]: event.target.value }));
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setComplete(true);
    clearCart();
  };

  if (complete) {
    return <div className="site-shell"><SiteHeader /><main className="container page-main checkout-complete"><CheckCircle2 size={44} /><span className="eyebrow">Demo complete</span><h1>Your setup is<br /><em>on its way.</em></h1><p>No order was created and no payment was taken. This completion state is here to demonstrate the intended V1 checkout flow.</p><Link href="/shop" className="button-primary button-primary--inline">Return to the edit <ArrowRight size={15} /></Link></main><SiteFooter /></div>;
  }

  if (!items.length) {
    return <div className="site-shell"><SiteHeader /><main className="container page-main checkout-complete"><span className="eyebrow">Checkout / empty</span><h1>Your bag is<br /><em>waiting.</em></h1><p>Add a piece before entering the demo checkout.</p><Link href="/shop" className="button-primary button-primary--inline">Browse the edit <ArrowRight size={15} /></Link></main><SiteFooter /></div>;
  }

  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="container page-main checkout-page">
        <Link href="/cart" className="back-link"><ArrowLeft size={15} /> Back to bag</Link>
        <div className="checkout-heading"><div><span className="eyebrow">Checkout / demo flow</span><h1>Make it<br /><em>easy.</em></h1></div><div className="checkout-lock"><LockKeyhole size={15} /> No payment connection</div></div>
        <div className="checkout-layout">
          <form className="checkout-form" onSubmit={handleSubmit}>
            <section className="form-section"><div className="form-section__heading"><span>01</span><h2>Contact</h2></div><div className="form-grid"><div className="field field--full"><Label htmlFor="name">Name</Label><Input id="name" required value={form.name} onChange={update("name")} placeholder="Your name" /></div><div className="field"><Label htmlFor="email">Email</Label><Input id="email" required type="email" value={form.email} onChange={update("email")} placeholder="you@example.com" /></div><div className="field"><Label htmlFor="phone">Phone</Label><Input id="phone" required value={form.phone} onChange={update("phone")} placeholder="+91" /></div></div></section>
            <section className="form-section"><div className="form-section__heading"><span>02</span><h2>Delivery</h2></div><div className="form-grid"><div className="field field--full"><Label htmlFor="address">Address</Label><Input id="address" required value={form.address} onChange={update("address")} placeholder="Where should the demo go?" /></div><div className="field"><Label htmlFor="city">City</Label><Input id="city" required value={form.city} onChange={update("city")} placeholder="City" /></div><div className="field"><Label htmlFor="postal">Postal code</Label><Input id="postal" required value={form.postal} onChange={update("postal")} placeholder="000 000" /></div></div></section>
            <div className="demo-callout"><span>DEMO CHECKOUT</span><p>These fields are for interaction testing only. No payment, delivery request or real order is processed.</p></div>
            <button className="buy-button buy-button--wide" type="submit">Complete demo order <ArrowRight size={16} /></button>
          </form>
          <aside className="checkout-summary"><span className="eyebrow">Your selection</span><div className="checkout-summary__items">{items.map(({ product, quantity, lineTotal }) => <div className="checkout-summary__item" key={product.id}><div><span>{String(quantity).padStart(2, "0")} × {product.name}</span><small>{product.categoryLabel}</small></div><strong>{formatINR(lineTotal)}</strong></div>)}</div><div className="summary-total"><span>Total / demo</span><strong>{formatINR(subtotal)}</strong></div><p className="summary-note">INR pricing shown for the V1 catalogue. Shipping and final policies will be defined before launch.</p></aside>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
