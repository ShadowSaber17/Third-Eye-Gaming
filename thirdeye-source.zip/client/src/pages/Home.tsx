import { motion } from "framer-motion";
import { ArrowDownRight, ArrowRight, Crosshair, MoveUpRight } from "lucide-react";
import { Link } from "wouter";
import { imageAssets, products } from "@/data/products";
import { BrandMark, ProductCard, PrimaryButton, SectionLabel, SiteFooter, SiteHeader, MetaStrip } from "@/components/storefront";

const categories = [
  { label: "Keycaps", detail: "Surface / identity", href: "/category/keycaps", image: imageAssets.keycaps, number: "01" },
  { label: "Cables", detail: "Connection / order", href: "/category/cables", image: imageAssets.cable, number: "02" },
  { label: "Mouse accessories", detail: "Control / contact", href: "/category/mouse-accessories", image: imageAssets.mouse, number: "03" },
];

export default function Home() {
  return (
    <div className="site-shell">
      <SiteHeader />
      <main>
        <section className="hero container">
          <motion.div className="hero__copy" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <motion.div className="home-logo-motion" initial={{ opacity: 0, x: -18 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.15 }}>
              <motion.div animate={{ rotate: [0, 2, 0, -2, 0] }} transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}>
                <BrandMark />
              </motion.div>
              <motion.span className="home-logo-motion__beacon" animate={{ scale: [1, 1.35, 1], opacity: [0.45, 1, 0.45] }} transition={{ duration: 2.1, repeat: Infinity, ease: "easeInOut" }} aria-hidden="true" />
              <span className="home-logo-motion__label">ACTIVE SIGNAL / HOME</span>
            </motion.div>
            <MetaStrip items={["THIRD EYE GAMING", "V1 / TEST CATALOG", "INR PRICING"]} />
            <p className="hero__kicker">For the parts you touch.</p>
            <h1>Make the setup<br /><span>feel like yours.</span></h1>
            <p className="hero__description">Keycaps, cables and small upgrades for people who notice the difference between a desk and their desk.</p>
            <div className="hero__actions">
              <PrimaryButton href="/shop">Shop the V1 edit</PrimaryButton>
              <Link href="/about" className="text-link">Read the point of view <ArrowRight size={15} /></Link>
            </div>
          </motion.div>
          <motion.div className="hero__visual" initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1, borderColor: ["#b9ff00", "#2551ff", "#b9ff00"] }} transition={{ duration: 1.1, delay: 0.08, borderColor: { duration: 4.5, repeat: Infinity, ease: "easeInOut" } }} whileHover={{ scale: 1.018 }}>
            <motion.img src={imageAssets.hero} alt="Mechanical keyboard accessories arranged on a graphite workbench" animate={{ scale: [1, 1.08, 1], rotate: [0, 0.35, 0] }} transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }} />
            <div className="hero__scan" aria-hidden="true" />
            <motion.div className="hero__target" animate={{ rotate: [0, 90, 180, 270, 360], scale: [0.82, 1, 0.82] }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }}><Crosshair size={42} strokeWidth={1.2} /><span>LOCK / 01</span></motion.div>
            <div className="hero__visual-note hero__visual-note--top"><span className="signal-dot" />CURRENT DROP <strong>01—06</strong></div>
            <div className="hero__visual-note hero__visual-note--bottom">A desk is a collection<br /><strong>of small decisions.</strong></div>
            <div className="hero__visual-index">TE / 001</div>
          </motion.div>
        </section>

        <section className="ticker" aria-label="Brand statement">
          <div className="ticker__track">
            <span>SMALL PARTS / BIG PERSONALITY</span><span>SMALL PARTS / BIG PERSONALITY</span><span>SMALL PARTS / BIG PERSONALITY</span>
          </div>
        </section>

        <section className="category-section container section-block">
          <SectionLabel eyebrow="Start here" title="Choose your signal" action={<span className="section-index">03 paths / 01 setup</span>} />
          <div className="category-list">
            {categories.map((category, index) => (
              <motion.div key={category.href} className="category-row" initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.08 }}>
                <span className="category-row__number">{category.number}</span>
                <Link href={category.href} className="category-row__main">
                  <div className="category-row__name"><span>{category.label}</span><MoveUpRight size={18} /></div>
                  <span className="category-row__detail">{category.detail}</span>
                </Link>
                <div className="category-row__image"><img src={category.image} alt="" /></div>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="feature-block container section-block">
          <div className="feature-block__intro">
            <span className="eyebrow">The first edit</span>
            <h2>A few good<br /><em>starting points.</em></h2>
            <p>Nothing here is trying to be everything. This is a tight placeholder catalogue for the way a good setup comes together: one deliberate piece, then another.</p>
            <Link href="/shop" className="text-link">View all pieces <ArrowRight size={15} /></Link>
          </div>
          <div className="feature-block__products">
            {products.slice(0, 3).map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}
          </div>
        </section>

        <section className="statement-band">
          <div className="container statement-band__inner">
            <span className="eyebrow">Why Third Eye</span>
            <h2>Not louder.<br /><span>More intentional.</span></h2>
            <div className="statement-band__side">
              <span className="statement-band__mark">03 / 03</span>
              <p>Built around the small parts that change how a setup feels, looks and moves through your day.</p>
              <Link href="/about" className="button-light">The point of view <ArrowDownRight size={15} /></Link>
            </div>
          </div>
        </section>

        <section className="shop-grid-section container section-block">
          <SectionLabel eyebrow="On the desk" title="Build from the touchpoints" action={<span className="section-index">Browse the edit / →</span>} />
          <div className="shop-grid-section__grid">
            <motion.div className="shop-grid-section__poster" initial={{ opacity: 0, x: -12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="poster__label">SETUP NOTE / 001</div>
              <div className="poster__quote">“The best upgrade is the one you notice every day.”</div>
              <div className="poster__footer"><span>THIRD EYE GAMING</span><span>IND / 2026</span></div>
            </motion.div>
            <div className="shop-grid-section__products">
              {products.slice(3).map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
