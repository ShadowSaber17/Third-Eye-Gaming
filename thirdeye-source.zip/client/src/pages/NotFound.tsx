import { useEffect } from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { SiteFooter, SiteHeader } from "@/components/storefront";

const NOT_FOUND_PATH = "/404";

export default function NotFound() {
  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex";
    document.head.appendChild(robots);
    if (window.location.pathname.replace(/\/$/, "") !== NOT_FOUND_PATH) window.location.replace(NOT_FOUND_PATH);
    return () => robots.remove();
  }, []);

  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="container page-main not-found">
        <span className="eyebrow">404 / signal lost</span>
        <h1>That piece<br /><em>isn't here.</em></h1>
        <p>Try the current edit instead. The catalogue is still taking shape.</p>
        <Link href="/shop" className="back-link"><ArrowLeft size={15} /> Back to the shop</Link>
      </main>
      <SiteFooter />
    </div>
  );
}
