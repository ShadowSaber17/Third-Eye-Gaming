import { useState } from "react";
import { ArrowLeft, ArrowRight, Check, ShieldCheck } from "lucide-react";
import { useLocation, useParams, Link } from "wouter";
import { toast } from "sonner";
import { getProduct, getRelatedProducts, formatINR } from "@/data/products";
import { useCart } from "@/contexts/CartContext";
import { ProductCard, PrimaryButton, SiteFooter, SiteHeader } from "@/components/storefront";
import NotFound from "@/pages/NotFound";

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>();
  const product = getProduct(slug);
  const [quantity, setQuantity] = useState(1);
  const [selectedOption, setSelectedOption] = useState(product?.options?.[0]?.values[0] ?? "Standard");
  const { addToCart } = useCart();
  const [, navigate] = useLocation();

  if (!product) return <NotFound />;
  const related = getRelatedProducts(product);

  const handleAdd = () => {
    addToCart(product.id, quantity);
    toast.success("Added to your bag", { description: `${product.name} · ${formatINR(product.price * quantity)}` });
  };

  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="container page-main product-page">
        <Link href="/shop" className="back-link"><ArrowLeft size={15} /> Back to the edit</Link>
        <section className="product-layout">
          <div className="product-gallery">
            <div className="product-gallery__main"><span className="product-gallery__index">{product.index}</span><img src={product.image} alt={product.name} /></div>
            <div className="product-gallery__caption"><span>IMAGE / PLACEHOLDER</span><span>V1 CATALOGUE</span></div>
          </div>
          <div className="product-info">
            <span className="eyebrow">{product.collection} / {product.categoryLabel}</span>
            <h1>{product.name}</h1>
            <p className="product-info__price">{formatINR(product.price)}</p>
            <p className="product-info__description">{product.description}</p>
            <div className="product-info__notice"><ShieldCheck size={17} /><span>Placeholder content only. Final product detail and policies will be added before live commerce.</span></div>
            {product.options?.map(option => <label className="product-option" key={option.label}><span>{option.label}</span><select value={selectedOption} onChange={event => setSelectedOption(event.target.value)}>{option.values.map(value => <option key={value}>{value}</option>)}</select></label>)}
            <div className="product-buy-row"><div className="quantity-control quantity-control--large"><button onClick={() => setQuantity(value => Math.max(1, value - 1))} aria-label="Decrease quantity">−</button><span>{String(quantity).padStart(2, "0")}</span><button onClick={() => setQuantity(value => value + 1)} aria-label="Increase quantity">+</button></div><button className="buy-button" onClick={handleAdd}>Add to bag <ArrowRight size={16} /></button></div>
            <button className="checkout-now" onClick={() => { handleAdd(); navigate("/cart"); }}>Add & view bag <ArrowRight size={15} /></button>
            <div className="product-info__details"><div><span className="micro-label">Product note</span><p>{product.detailLine}</p></div><div><span className="micro-label">Pair it with</span><p>{related[0]?.name ?? "More from the edit"}</p></div></div>
          </div>
        </section>
        <section className="related-section"><div className="related-section__header"><div><span className="eyebrow">Keep building</span><h2>One thing leads<br /><em>to another.</em></h2></div><span className="related-section__note"><Check size={14} /> Curated for this piece</span></div><div className="related-grid">{related.map((item, index) => <ProductCard key={item.id} product={item} index={index} />)}</div></section>
      </main>
      <SiteFooter />
    </div>
  );
}
