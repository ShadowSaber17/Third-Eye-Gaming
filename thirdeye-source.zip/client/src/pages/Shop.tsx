import { useMemo, useState } from "react";
import { ArrowDownUp, SlidersHorizontal } from "lucide-react";
import { categoryMeta, CategoryKey, products } from "@/data/products";
import { ProductCard, SectionLabel, SiteFooter, SiteHeader } from "@/components/storefront";

const filters = [
  { key: "all", label: "All pieces" },
  { key: "keycaps", label: "Keycaps" },
  { key: "cables", label: "Cables" },
  { key: "mouse-accessories", label: "Mouse" },
  { key: "keychains", label: "Keychains" },
];

export default function Shop() {
  const [active, setActive] = useState("all");
  const [sort, setSort] = useState("featured");
  const visibleProducts = useMemo(() => {
    const filtered = active === "all" ? products : products.filter(product => product.category === active);
    return [...filtered].sort((a, b) => sort === "price" ? a.price - b.price : Number(a.id) - Number(b.id));
  }, [active, sort]);

  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="container page-main">
        <section className="page-hero page-hero--shop">
          <div>
            <span className="eyebrow">Catalogue / V1</span>
            <h1>Good pieces,<br /><em>well placed.</em></h1>
          </div>
          <p>Browse the placeholder edit: tactile upgrades for mechanical-keyboard and gaming setups, arranged for the way you actually shop.</p>
        </section>
        <div className="shop-toolbar">
          <div className="filter-row" aria-label="Product categories">
            <SlidersHorizontal size={15} />
            {filters.map(filter => <button key={filter.key} className={active === filter.key ? "filter-chip is-active" : "filter-chip"} onClick={() => setActive(filter.key)}>{filter.label}</button>)}
          </div>
          <label className="sort-control"><ArrowDownUp size={14} /><span>Sort</span><select value={sort} onChange={event => setSort(event.target.value)}><option value="featured">Featured</option><option value="price">Price / low to high</option></select></label>
        </div>
        <div className="catalogue-grid">
          {visibleProducts.map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}
        </div>
        <div className="catalogue-note"><span>V1 / PLACEHOLDER CATALOGUE</span><span>{visibleProducts.length} pieces in view</span><span>INR pricing · demo checkout</span></div>
      </main>
      <SiteFooter />
    </div>
  );
}

export function CategoryPage({ category }: { category: CategoryKey }) {
  const meta = categoryMeta[category];
  const categoryProducts = products.filter(product => product.category === category);
  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="container page-main">
        <section className="category-hero">
          <div className="category-hero__copy">
            <span className="eyebrow">Collection / {meta.eyebrow}</span>
            <h1>{meta.label}<br /><em>for the setup.</em></h1>
            <p>{meta.description}</p>
            <span className="category-hero__count">{String(categoryProducts.length).padStart(2, "0")} placeholder pieces</span>
          </div>
          <div className="category-hero__image"><img src={meta.image} alt="" /><span>TE / CATEGORY / {category.toUpperCase()}</span></div>
        </section>
        <div className="category-grid">{categoryProducts.map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}</div>
      </main>
      <SiteFooter />
    </div>
  );
}
